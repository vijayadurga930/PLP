package com.capgemini.bankingproject.service;

import java.util.Map;

import com.capgemini.bankingproject.bean.Customer;
import com.capgemini.bankingproject.bean.Transcation;
import com.capgemini.bankingproject.exception.BankException;

public interface IBankService {
	public boolean custNameValidation(String name) throws BankException;
	public boolean custMobValidation(String mobile) throws BankException;
	public boolean custEmailValidation(String email)throws BankException;
	public long addToCustomer(Customer customer) throws BankException;
	public boolean validateDestinationAccount(int custId) throws BankException;
	public int transferFunds(Transcation transaction,int sourceCustId,int destinationCustId) throws BankException;
	void showBalance(int custId) throws BankException;
	public void depositBalance(int custId,double amount) throws BankException;
	public void withdrawBalance(int custId, double amount)throws BankException;
	public boolean validateTransactionId(int transId)throws BankException;
	public Map<Integer, Transcation> printTransactionDetails(int transId) throws BankException;
	
	

}
