package com.capgemini.bankingproject.dao;

import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import com.capgemini.bankingproject.bean.Customer;
import com.capgemini.bankingproject.bean.Transcation;



public class BankDaoImpl implements IBankDao {
	
	public static Map<Integer, Customer> customerList = new HashMap<>();
	public static Map<Integer, Transcation> transactionList = new HashMap<>();
	@Override
	public long addToCustomer(Customer customer) {
		int custId =(int) (Math.random()*10000);
		long accountNo = (long) (Math.random()*100000000L);
		customer.setCustId(custId);
		customer.setAccountNo(accountNo);
		getCustomerList().put(custId, customer);
		System.out.println("Your CustId is:"+ custId);
		return accountNo;
		
		
	}

	public static Map<Integer, Customer> getCustomerList() {
		return customerList;
	}
	public static void setCustomerList(Map<Integer, Customer> customerList) {
		BankDaoImpl.customerList = customerList;
	}
	public static Map<Integer,Transcation> gettransactionList() {
		return transactionList;
	}
	public static void settransactionList(Map<Integer, Transcation> transactionList) {
		BankDaoImpl.transactionList = transactionList;
	}

	@Override
	public int transferFunds(Transcation transaction, int sourceCustId,int destinationCustId) {
		
		int transId= 0;
		double balanceSourceCust = 0.0;
		double balanceDestinationCust = 0.0;
		Customer customer1= BankDaoImpl.customerList.get(sourceCustId);
		Customer customer2= BankDaoImpl.customerList.get(destinationCustId);
		Set keys= customerList.keySet();
		Iterator iterator =keys.iterator();
		while(iterator.hasNext()){
			int key = (int) iterator.next();
			if( key == sourceCustId) {
				balanceSourceCust =customer1.getBalance()- transaction.getAmount();
				if(balanceSourceCust<customer1.getBalance()) {
					transaction.setTransType("Debit");
				}
				else
					transaction.setTransType("Credit");
				customer1.setBalance(balanceSourceCust);
				balanceDestinationCust =customer1.getBalance()+transaction.getAmount();
				customer2.setBalance(balanceDestinationCust);
				break;
				
			}
			
		}
		
		transId = (int) (Math.random()*1000);
		Date transDate = new Date();
		transaction.setTransDate(transDate);
		transaction.setTransId(transId);
		transactionList.put(transId, transaction);
		return transId;
	}

	@Override
	public void showBalance(int custId) {
		Customer customer= BankDaoImpl.customerList.get(custId);
		Set keys= customerList.keySet();
		Iterator iterator =keys.iterator();
		while(iterator.hasNext()){
			int key = (int) iterator.next();
			if( key == custId) {
				double balance = customer.getBalance();
				System.out.println("Your available balance is:"+balance);
			}
	}
	}

	@Override
	public void depositBalance(int custId,double amount) {
		
		Customer customer= BankDaoImpl.customerList.get(custId);
		Set keys= customerList.keySet();
		Iterator iterator =keys.iterator();
		while(iterator.hasNext()){
			int key = (int) iterator.next();
			if( key == custId) {
				double balance = customer.getBalance()+amount;
				customer.setBalance(balance);
				System.out.println("Balance Succefully deposited!!Your available balance is:"+balance);
				
			}
			
	}
		
	}

	@Override
	public void withdrawBalance(int custId, double amount) {
		Customer customer= BankDaoImpl.customerList.get(custId);
		Set keys= customerList.keySet();
		Iterator iterator =keys.iterator();
		while(iterator.hasNext()){
			int key = (int) iterator.next();
			if( key == custId) {
				double balance = customer.getBalance()-amount;
				customer.setBalance(balance);
				
				System.out.println("Transaction Succesfull!!Your available balance is:"+balance);
			}
	}
		
	}

	@Override
	public Map<Integer, Transcation> printTransactionDetails(int transId) {
		return BankDaoImpl.gettransactionList();
		
	}
	
	
	

}
