package com.capgemini.bankingproject.dao;

import java.util.HashMap;
import java.util.Map;

import com.capgemini.bankingproject.bean.Customer;
import com.capgemini.bankingproject.bean.Transcation;
import com.capgemini.bankingproject.exception.BankException;

public interface IBankDao {
	public static Map<Integer, Customer> customerList = new HashMap<>();
	long addToCustomer(Customer customer)throws BankException;
	void showBalance(int custId)throws BankException;
	int transferFunds(Transcation transaction,int sourceCustId,int destinationCustId) throws BankException;
	void depositBalance(int custId,double amount)throws BankException;
	void withdrawBalance(int custId, double amount)throws BankException;
	public Map<Integer, Transcation> printTransactionDetails(int transId);

	



}
