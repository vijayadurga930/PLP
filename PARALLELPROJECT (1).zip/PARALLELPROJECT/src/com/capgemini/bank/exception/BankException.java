package com.capgemini.bank.exception;

public class BankException  extends Exception{

	public BankException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
