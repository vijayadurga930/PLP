package com.capgemini.bank.dao;

import java.util.List;

import com.capgemini.bank.beans.Customer;
import com.capgemini.bank.exception.BankException;

public interface BankDao {

	int getCustomerId()throws BankException;

	List<Customer> addCustomer(String name, int password, double ammount)throws BankException;

}
