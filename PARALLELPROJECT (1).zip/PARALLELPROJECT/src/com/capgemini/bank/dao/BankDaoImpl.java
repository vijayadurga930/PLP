package com.capgemini.bank.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.capgemini.bank.beans.Customer;
import com.capgemini.bank.exception.BankException;

public class BankDaoImpl implements BankDao {
	private static Map<Integer, Customer> map= new HashMap<>();
	static {
		map.put(1234, new Customer("satya",6000.00));
		map.put(1243, new Customer("satyadevi",7000.00));
		map.put(1234, new Customer("vsatya",6000.00));
	}

	@Override
	public int getCustomerId() throws BankException {
		// TODO Auto-generated method stub
		double generatedId=Math.random()*10000;
		int Id=(int)generatedId;
		return Id;
	}

	@Override
	public List<Customer> addCustomer(String name, int password, double ammount) throws BankException {
		// TODO Auto-generated method stub
		map.put(password,new Customer (name,ammount));
		return null;
	}

}
