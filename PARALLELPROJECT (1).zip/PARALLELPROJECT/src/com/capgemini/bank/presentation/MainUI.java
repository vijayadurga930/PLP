package com.capgemini.bank.presentation;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

import com.capgemini.bank.beans.Customer;
import com.capgemini.bank.exception.BankException;
import com.capgemini.bank.service.BankService;
import com.capgemini.bank.service.BankServiceImpl;

public class MainUI {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		BankService service = new BankServiceImpl();
		List<Customer> customers= new ArrayList<>();
		boolean choiceflag = false;

		do {

			System.out.println("1.Create account \n 2.Login \n 3. Exit");
			System.out.println("enter choice:");
			int choice = 0;
			try {
				choice = scanner.nextInt();
				choiceflag = false;
				switch (choice) {
				case 1: {
                   System.out.println("Enter user name:");
                   String name=scanner.next();
                   System.out.println("Enter email:");
                   String email=scanner.next();
                   System.out.println("Enter phone number:");
                   String phone=scanner.next();
                   System.out.println("Enter Address:");
                   String address=scanner.next();
                   System.out.println("Enter Account:");
                   double ammount=scanner.nextDouble();
                   try {
					int password=service.getCustomerId();
					customers= service.addCustomer(name,password,ammount);
					
				} catch (BankException e) {
					
					e.printStackTrace();
				}
				}
					break;
				case 2: {

				}
					break;
				case 3: {

				}
					break;
				default:{
					System.err.println("choice must be 1,2,3");
					choiceflag=true;
				}
					break;
				}

			} catch (InputMismatchException e) {
				choiceflag = true;
				System.err.println("please enter digits");
			}

		} while (choiceflag);

	}

}
