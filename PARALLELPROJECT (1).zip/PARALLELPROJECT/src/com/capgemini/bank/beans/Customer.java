package com.capgemini.bank.beans;

import java.util.List;

public class Customer {
private int customerId;
private String name;
private String email;
private String mobile;
private String address;
private double amount;
private Account account;
private List<Transaction> transaction;
public Customer() {
	super();
	// TODO Auto-generated constructor stub
}
public Customer(int customerId, String name, String email, String mobile, String address, Account account,
		List<Transaction> transaction, double amount) {
	super();
	this.customerId = customerId;
	this.name = name;
	this.email = email;
	this.mobile = mobile;
	this.address = address;
	this.account = account;
	this.amount=amount;
	this.transaction = transaction;
}
public Customer(int customerId, String name, String email, String mobile, String address, Account account) {
	super();
	this.customerId = customerId;
	this.name = name;
	this.email = email;
	this.mobile = mobile;
	this.address = address;
	this.account = account;
	
	
}

public Customer(String string, double d) {
	// TODO Auto-generated constructor stub
	this.name = string;
	this.amount = d;
}
public int getCustomerId() {
	return customerId;
}
public void setCustomerId(int customerId) {
	this.customerId = customerId;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getEmail() {
	return email;
}
public void setEmail(String email) {
	this.email = email;
}
public String getMobile() {
	return mobile;
}
public void setMobile(String mobile) {
	this.mobile = mobile;
}
public String getAddress() {
	return address;
}
public void setAddress(String address) {
	this.address = address;
}
public Account getAccount() {
	return account;
}
public void setAccount(Account account) {
	this.account = account;
}
public List<Transaction> getTransaction() {
	return transaction;
}
public void setTransaction(List<Transaction> transaction) {
	this.transaction = transaction;
}
@Override
public String toString() {
	return "Customer [customerId=" + customerId + ", name=" + name + ", email=" + email + ", mobile=" + mobile
			+ ", address=" + address + ", account=" + account + ", transaction=" + transaction + "]";
}


}
