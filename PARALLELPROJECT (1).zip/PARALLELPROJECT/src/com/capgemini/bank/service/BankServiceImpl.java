package com.capgemini.bank.service;

import java.util.List;

import com.capgemini.bank.beans.Customer;
import com.capgemini.bank.dao.BankDao;
import com.capgemini.bank.dao.BankDaoImpl;
import com.capgemini.bank.exception.BankException;

public class BankServiceImpl implements BankService {
	BankDao dao = new BankDaoImpl();

	@Override
	public int getCustomerId() throws BankException {
		
		return dao.getCustomerId();
	}

	@Override
	public List<Customer> addCustomer(String name, int password, double ammount) throws BankException {
		// TODO Auto-generated method stub
		return dao.addCustomer(name,password,ammount);
	}

}
