package com.capgemini.bank.service;

import java.util.List;

import com.capgemini.bank.beans.Customer;
import com.capgemini.bank.exception.BankException;

public interface BankService {

	int getCustomerId()throws BankException;

	List<Customer> addCustomer(String name, int password, double ammount)throws BankException;
	

}
